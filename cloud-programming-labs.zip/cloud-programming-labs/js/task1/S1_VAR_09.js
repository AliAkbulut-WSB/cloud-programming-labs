try {
  console.log(typeof someUndeclaredName);
} catch (error) {
  console.log("Error occurred:", error);
}
